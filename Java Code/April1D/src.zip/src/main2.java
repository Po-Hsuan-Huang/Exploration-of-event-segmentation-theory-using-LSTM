import java.util.ArrayList;
import java.util.Arrays;

import de.jannlab.data.Sample;
import de.jannlab.data.SampleSet;
import de.jannlab.math.Matrix;


/**
 *  This Main Class runs the 1-D simulation of a point ball bouncing between [0, 1] with
 *  constant velocity. The Brain that made of LSTM model tries to predict the location
 *  of the ball in the next time step.
 *  
 * */

public class main2 {




	/** parameters of the physical model */

	public static double physicsModel(Ball ball,double input) {

		// left boundary of world
		final double WorldLeftBound = -1.0;
		// right boundary of world
		final double WorldRightBound = 1.0;

		if (ball.isStart()) {
			if (input <= WorldLeftBound + Math.pow(10,-6) && ball.getVelocity() < 0) {
				ball.bounce();
			}
			if (input >= WorldRightBound - Math.pow(10,-6) && ball.getVelocity() > 0) {
				ball.bounce();
			}
			ball.fly();
		}
		return ball.getLoc();
	}




	/** Parameters for main method */

	public static void main(String[] args) {
		/**
			DAFAULT VALUES:
					int timespan = 2000;
					int T = 100;
					double velocity = 0.05;
					double location = 0;
		 */

		// Physics params
		int timespan = 50000;
		// training sequence length.
		int window = 6;

		// Initialization

		double velocity = 1;
		double location = 0;
		double currentlocation = location;
		double nextlocation  = location + velocity;
		double[] data = {currentlocation};
		double[] target = {velocity};


		//Initiation of models
		Ball ball  = new Ball(location,velocity);
		SampleSequencer sequencer = new SampleSequencer();
		Sample sample = sequencer.getSample(data, target) ;
		HLSTM Brain = new HLSTM(1,2,1); // JannLab doesn't support online learning.
		// Training phase
		// Brain.init();
		ball.start();


		//Write file
		ArrayList<Double> PRED = new ArrayList<Double>();
		ArrayList<Double> TARGET = new ArrayList<Double>();
		ArrayList<Double> ERR = new ArrayList<Double>();
		ArrayList<Double> ERRVAR = new ArrayList<Double>();

		// Start Simulation
		for (int t = 0; t < timespan; t++) {

			//System.out.println("\n" + t);

			//phyiscs
			currentlocation = ball.getLoc();
			//System.out.println("loc : " + currentlocation);
			// Make Prediction
			data[0] = currentlocation;
			double[] predict = Brain.predict(data);
			//System.out.println("predction : " + predict[0]);
			// WRITE FILE
			PRED.add(predict[0]);
			WriteFiles.Write(PRED, "pred");

			//			 System.out.println("current loc : " + currentlocation);

			nextlocation= physicsModel( ball, currentlocation);
			target[0] = ball.getVelocity();
			//		 	 System.out.println("data length : "+ data.length);
			//		 	 System.out.println("target length : "+ target.length);
			sample  = sequencer.getSample(data,target);

			if(t > window) {
				Brain.update(sample);


				//WRITE FILE
				TARGET.add(target[0]);
				WriteFiles.Write(TARGET, "target");
				// UPDATE ERROR
				Brain.updateError(predict[0]-target[0]);

				ERR.add(Brain.getMeanError());
				ERRVAR.add(Brain.getErrorVariance());
				System.out.println("d:" + data[0] + " p:" + predict[0] + " t:"+ target[0]);
				System.out.println("error : " + Brain.getMeanError());

				//			 System.out.println("Mean error : " + Brain.getMeanError());
			}
		}
		// WRITE FILE
		WriteFiles.Write(ERR, "err");
		WriteFiles.Write(ERRVAR, "errvar");



		ball.stop();

		//		double[] inversepred = Brain.inverseForwardModel(currentlocation);
		//		System.out.println("inverse pred : " + Arrays.toString(inversepred));

	}
}




